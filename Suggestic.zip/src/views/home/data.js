
export const howItWorksTips = [
  "Applications open",
  "Complete & pass a screening test",
  "Enhance career development",
  "Complete your exam",
  "Receive exam results and certificate",
];

export const whyContent = []