export const routes = {
    home: {
        route: "/"
    }
};